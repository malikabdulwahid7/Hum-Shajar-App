import 'package:flutter/material.dart';

/// Central place for the app's look & feel. Palette is pulled from the
/// book cover: soft fog-white background, warm amber/terracotta tree
/// tones, deep charcoal ink for reading text.
class AppColors {
  static const cream = Color(0xFFFBF7F1);
  static const paper = Color(0xFFF6EFE4);
  static const ink = Color(0xFF2B2622);
  static const inkSoft = Color(0xFF5B534A);
  static const amber = Color(0xFFC17A3E);
  static const amberDeep = Color(0xFF9C5B27);
  static const mist = Color(0xFFD9CFC0);
  static const divider = Color(0xFFE3D9C8);
}

/// The custom Urdu Nastaleeq typeface. Register the actual font file at
/// assets/fonts/JameelNooriNastaleeq.ttf and in pubspec.yaml — see
/// FONT_SETUP.md. Referencing the family name here is all screens need.
const String kNastaleeqFont = 'JameelNooriNastaleeq';

class AppTheme {
  static ThemeData light() {
    final base = ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      scaffoldBackgroundColor: AppColors.cream,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.amberDeep,
        brightness: Brightness.light,
        surface: AppColors.cream,
      ),
      fontFamily: kNastaleeqFont,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.cream,
        foregroundColor: AppColors.ink,
        elevation: 0,
        scrolledUnderElevation: 1,
        centerTitle: true,
        titleTextStyle: TextStyle(
          fontFamily: kNastaleeqFont,
          color: AppColors.ink,
          fontSize: 22,
        ),
      ),
      dividerTheme: const DividerThemeData(
        color: AppColors.divider,
        thickness: 1,
        space: 32,
      ),
    );

    return base.copyWith(
      textTheme: base.textTheme.apply(
        fontFamily: kNastaleeqFont,
        bodyColor: AppColors.ink,
        displayColor: AppColors.ink,
      ),
    );
  }

  /// Large display style for the book title on the landing page.
  static const titleDisplay = TextStyle(
    fontFamily: kNastaleeqFont,
    fontSize: 56,
    color: AppColors.ink,
    height: 1.3,
  );

  /// Style used for a poem's couplet lines on the reading screen —
  /// generously sized and spaced for comfortable Nastaleeq reading.
  static const verseText = TextStyle(
    fontFamily: kNastaleeqFont,
    fontSize: 26,
    height: 2.2,
    color: AppColors.ink,
  );

  /// Style for section headers (چیپٹر titles).
  static const sectionHeader = TextStyle(
    fontFamily: kNastaleeqFont,
    fontSize: 30,
    color: AppColors.amberDeep,
  );

  /// Style used for a poem title / preview line in list rows.
  static const listTitle = TextStyle(
    fontFamily: kNastaleeqFont,
    fontSize: 20,
    color: AppColors.ink,
    height: 1.6,
  );
}
