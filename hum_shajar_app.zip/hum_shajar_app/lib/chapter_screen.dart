import 'package:flutter/material.dart';
import 'poem.dart';
import 'app_theme.dart';
import 'poem_tile.dart';
import 'poem_screen.dart';

/// Lists every poem that belongs to one chapter/section (e.g. all the
/// ghazals, or the naats & salam).
class ChapterScreen extends StatelessWidget {
  final Chapter chapter;

  const ChapterScreen({super.key, required this.chapter});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.cream,
      appBar: AppBar(title: Text(chapter.titleUrdu)),
      body: chapter.poems.isEmpty
          ? Center(
              child: Text(
                'یہ حصہ ابھی شامل نہیں کیا گیا',
                style: const TextStyle(
                  fontFamily: kNastaleeqFont,
                  fontSize: 18,
                  color: AppColors.inkSoft,
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 32),
              itemCount: chapter.poems.length,
              separatorBuilder: (_, __) => const Divider(),
              itemBuilder: (context, index) {
                final poem = chapter.poems[index];
                return PoemTile(
                  poem: poem,
                  onTap: () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => PoemScreen(
                          poem: poem,
                          chapterTitle: chapter.titleUrdu,
                        ),
                      ),
                    );
                  },
                );
              },
            ),
    );
  }
}
