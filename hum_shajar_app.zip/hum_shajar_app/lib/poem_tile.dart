import 'package:flutter/material.dart';
import 'poem.dart';
import 'app_theme.dart';

/// A tappable row representing one poem inside a chapter's list —
/// shows the poem's opening line as its title.
class PoemTile extends StatelessWidget {
  final Poem poem;
  final VoidCallback onTap;

  const PoemTile({super.key, required this.poem, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(14),
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 6),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (poem.subtitle != null) ...[
                      Text(
                        poem.subtitle!,
                        style: const TextStyle(
                          fontFamily: kNastaleeqFont,
                          fontSize: 13,
                          color: AppColors.amberDeep,
                        ),
                      ),
                      const SizedBox(height: 4),
                    ],
                    Text(
                      poem.preview,
                      style: AppTheme.listTitle,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${poem.verses.length} اشعار',
                      style: const TextStyle(
                        fontFamily: kNastaleeqFont,
                        fontSize: 12,
                        color: AppColors.inkSoft,
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              const Icon(Icons.chevron_left, color: AppColors.mist),
            ],
          ),
        ),
      ),
    );
  }
}
