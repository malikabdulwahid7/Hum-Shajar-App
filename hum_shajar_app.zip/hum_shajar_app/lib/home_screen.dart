import 'package:flutter/material.dart';
import 'book_data.dart';
import 'app_theme.dart';
import 'chapter_card.dart';
import 'chapter_screen.dart';

/// The landing page of the app: cover-style hero with the book title,
/// author, and a short blurb, followed by the list of chapters/sections.
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.cream,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverToBoxAdapter(child: _HeroCover()),
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(20, 8, 20, 32),
              sliver: SliverList(
                delegate: SliverChildBuilderDelegate(
                  (context, index) {
                    final chapter = bookChapters[index];
                    return Padding(
                      padding: const EdgeInsets.only(bottom: 14),
                      child: ChapterCard(
                        chapter: chapter,
                        onTap: () {
                          Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => ChapterScreen(chapter: chapter),
                            ),
                          );
                        },
                      ),
                    );
                  },
                  childCount: bookChapters.length,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Cover-style header: soft gradient sky, a tree silhouette rendered in
/// pure Flutter (no image asset required), the book's title in Nastaleeq,
/// and the author's name — mirroring the printed cover of Hum Shajar.
class _HeroCover extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(24, 36, 24, 28),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [
            Color(0xFFFDF9F2),
            AppColors.paper,
          ],
        ),
      ),
      child: Column(
        children: [
          SizedBox(
            height: 150,
            width: 150,
            child: CustomPaint(painter: _TreePainter()),
          ),
          const SizedBox(height: 18),
          const Text('ہم شجر', style: AppTheme.titleDisplay),
          const SizedBox(height: 6),
          const Text(
            '(شاعری)',
            style: TextStyle(
              fontFamily: kNastaleeqFont,
              fontSize: 18,
              color: AppColors.inkSoft,
            ),
          ),
          const SizedBox(height: 14),
          Container(height: 1, width: 60, color: AppColors.mist),
          const SizedBox(height: 14),
          const Text(
            'حارث بلال',
            style: TextStyle(
              fontFamily: kNastaleeqFont,
              fontSize: 24,
              color: AppColors.amberDeep,
            ),
          ),
          const SizedBox(height: 4),
          const Text(
            'Poetry by Haris Bilal',
            style: TextStyle(fontSize: 12, color: AppColors.inkSoft, letterSpacing: 0.5),
          ),
        ],
      ),
    );
  }
}

/// A minimal single-tree silhouette painted with CustomPainter so the
/// cover has real art without needing an image asset. Swap this whole
/// widget for an Image.asset('assets/images/cover.jpg') if you'd rather
/// use the real cover photo — just drop the file in assets/images/.
class _TreePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final trunkPaint = Paint()
      ..color = AppColors.amberDeep
      ..style = PaintingStyle.stroke
      ..strokeWidth = 5
      ..strokeCap = StrokeCap.round;

    final canopyPaint = Paint()
      ..color = AppColors.amber.withValues(alpha: 0.85)
      ..style = PaintingStyle.fill;

    final w = size.width;
    final h = size.height;

    // Trunk
    canvas.drawLine(Offset(w * 0.5, h * 0.95), Offset(w * 0.5, h * 0.55), trunkPaint);
    // A few branches
    canvas.drawLine(Offset(w * 0.5, h * 0.7), Offset(w * 0.32, h * 0.5), trunkPaint);
    canvas.drawLine(Offset(w * 0.5, h * 0.62), Offset(w * 0.68, h * 0.42), trunkPaint);

    // Canopy — a loose cluster of circles to suggest foliage.
    final canopySpots = [
      Offset(w * 0.5, h * 0.42),
      Offset(w * 0.34, h * 0.48),
      Offset(w * 0.66, h * 0.46),
      Offset(w * 0.44, h * 0.3),
      Offset(w * 0.6, h * 0.32),
      Offset(w * 0.5, h * 0.2),
    ];
    for (final spot in canopySpots) {
      canvas.drawCircle(spot, w * 0.16, canopyPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
