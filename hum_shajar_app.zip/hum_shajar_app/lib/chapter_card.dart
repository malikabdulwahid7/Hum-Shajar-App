import 'package:flutter/material.dart';
import 'poem.dart';
import 'app_theme.dart';

/// A single chapter/section tile shown on the landing page — e.g.
/// "نعت و سلام" or "غزل" — with a poem count and a small leaf/tree glyph
/// to echo the cover artwork.
class ChapterCard extends StatelessWidget {
  final Chapter chapter;
  final VoidCallback onTap;

  const ChapterCard({super.key, required this.chapter, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Material(
      color: AppColors.paper,
      borderRadius: BorderRadius.circular(18),
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 22),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: AppColors.mist),
          ),
          child: Row(
            children: [
              Container(
                width: 48,
                height: 48,
                alignment: Alignment.center,
                decoration: const BoxDecoration(
                  color: AppColors.amber,
                  shape: BoxShape.circle,
                ),
                child: const Icon(
                  Icons.park_outlined,
                  color: AppColors.cream,
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(chapter.titleUrdu, style: AppTheme.sectionHeader),
                    const SizedBox(height: 4),
                    Text(
                      chapter.description,
                      style: const TextStyle(
                        fontFamily: kNastaleeqFont,
                        fontSize: 15,
                        color: AppColors.inkSoft,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Text(
                      '${chapter.poems.length} کلام',
                      style: const TextStyle(
                        fontFamily: kNastaleeqFont,
                        fontSize: 13,
                        color: AppColors.amberDeep,
                      ),
                    ),
                  ],
                ),
              ),
              const Icon(Icons.chevron_left, color: AppColors.inkSoft),
            ],
          ),
        ),
      ),
    );
  }
}
